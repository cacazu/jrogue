//! Semantic observations exposed by the gameplay engine, without hidden state.

use std::collections::BTreeMap;
use std::fmt;

use serde::{Deserialize, Serialize};

/// Maximum bytes in an English semantic identifier.
pub const MAX_TEXT_ID_BYTES: usize = 160;
/// Maximum typed arguments in an event.
pub const MAX_ARGUMENTS: usize = 64;
/// Maximum bytes in a public, untranslated free-text argument.
pub const MAX_TEXT_BYTES: usize = 65_536;

/// A stable English semantic identifier, independent of displayed language.
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(try_from = "String", into = "String")]
pub struct TextId(String);

impl TextId {
    /// Borrow the validated identifier.
    #[must_use]
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl TryFrom<String> for TextId {
    type Error = InvalidTextId;

    fn try_from(value: String) -> Result<Self, Self::Error> {
        let valid = !value.is_empty()
            && value.len() <= MAX_TEXT_ID_BYTES
            && value.split('.').all(|segment| {
                let mut bytes = segment.bytes();
                matches!(bytes.next(), Some(b'a'..=b'z'))
                    && bytes.all(|byte| {
                        byte.is_ascii_lowercase() || byte.is_ascii_digit() || byte == b'_'
                    })
            });
        if valid {
            Ok(Self(value))
        } else {
            Err(InvalidTextId)
        }
    }
}

impl From<TextId> for String {
    fn from(value: TextId) -> Self {
        value.0
    }
}

impl fmt::Display for TextId {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(self.as_str())
    }
}

/// An identifier is empty, too long, or not an English semantic key.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct InvalidTextId;

impl fmt::Display for InvalidTextId {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("invalid semantic text identifier")
    }
}

impl std::error::Error for InvalidTextId {}

/// An already selected public value. No object pointer or private effect index
/// crosses this boundary. User names, wishes, labels, and fruit remain literal
/// UTF-8 strings, including percent signs and braces.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(
    tag = "type",
    content = "value",
    rename_all = "snake_case",
    deny_unknown_fields
)]
pub enum TextArgument {
    Text(String),
    Integer(i64),
    Unsigned(u64),
    Boolean(bool),
    TextId(TextId),
}

/// An immutable gameplay or application observation captured at the source
/// output call, after the engine has selected names and random descriptions.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TextEvent {
    pub id: TextId,
    #[serde(default)]
    pub args: BTreeMap<String, TextArgument>,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn semantic_ids_validate_english_keys_and_reject_ambiguous_keys() {
        for valid in ["game.you_hit", "entity.orc", "ui.save.v1"] {
            assert!(TextId::try_from(valid.to_owned()).is_ok());
        }
        for invalid in ["", ".game", "game..hit", "Game.hit", "game.命中", "game.%s"] {
            assert!(TextId::try_from(invalid.to_owned()).is_err());
        }
    }

    #[test]
    fn unknown_event_fields_and_invalid_ids_are_rejected_before_use() {
        assert!(
            serde_json::from_str::<TextEvent>(r#"{"id":"game.hit","args":{},"effect_index":5}"#)
                .is_err()
        );
        assert!(serde_json::from_str::<TextEvent>(r#"{"id":"ゲーム.hit"}"#).is_err());
    }
}

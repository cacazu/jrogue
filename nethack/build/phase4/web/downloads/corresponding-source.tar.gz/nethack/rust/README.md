# NetHack Rust boundaries

The official NetHack 5.0.0 C engine owns gameplay rules, RNG, turns, knowledge,
and logical save data. This crate implements pure boundaries around that engine.
It is not a Rust rewrite of the NetHack gameplay engine.

| Module | Responsibility |
| --- | --- |
| `domain` | Validated English semantic text IDs and typed, already-public observations |
| `application` | Context-aware keyboard, touch, and gamepad command intents; complete UTF-8 text insertions |
| `presentation` | EN/JA JSON template formatting, Japanese default, explicit fallback diagnostics |
| `platform` | Opaque engine-save envelopes with source, ABI, version, size, encoding, and CRC32 checks |
| `ffi` | Borrowed-buffer adapter for the engine module's C/Wasm memory |

Formatting, repeated rendering, changing language, and input mapping never call
the engine or RNG. The C adapter must capture text IDs and visible arguments at
the source output call. This crate does not infer gameplay meaning from completed
English prose, and its tests do not establish complete game-text coverage.

Catalog JSON has `en` and `ja` maps, for example:

```json
{"en":{"game.you_hit":"You hit {monster} for {damage}."},"ja":{"game.you_hit":"{monster}に{damage}のダメージ。"}}
```

An event contains a semantic ID and typed arguments:

```json
{"id":"game.you_hit","args":{"monster":{"type":"text","value":"オーク"},"damage":{"type":"integer","value":4}}}
```

Argument types are `text`, `integer`, `unsigned`, `boolean`, and `text_id`.
`text_id` resolves an already-public, argument-free name in the catalog; names
with placeholders are rejected. Free text remains literal UTF-8, including
percent signs, braces, and emoji. Templates use `{name}`, and `{{`/`}}` escape
literal braces. Unknown IDs, malformed templates, missing/extra arguments, and
different EN/JA argument schemas return errors. A missing Japanese entry falls
back to English with a separate diagnostic flag.

`nethack_layers.h` defines the C ABI. Contexts are command=0, direction=1,
menu=2, More=3, text=4, yes/no=5. Movement controls only produce movement keys in
command/direction contexts. Operating-system Meta shortcuts are ignored; Alt
encodes the original NetHack meta high bit. Unicode insertions use the text
adapter rather than being narrowed to command bytes. Browser adapters own
composition handling, gamepad deadzones, repeat timing, and engine prompt state.
`nh_rust_direction_pad` accepts the public layout reported by the engine:
vi=0, number-pad=1, phone-pad=2, QWERTZ=3. Number-pad running emits the original
Meta digit rather than uppercase or an invented command. These mappings follow
official `src/cmd.c` direction tables and run bindings; options stay in the engine.
`nh_rust_text_insert` validates and copies a complete UTF-8 text submission in
text context. Embedded NUL is rejected; empty completed text is valid. It does
not submit commands or mutate the engine.

All input buffers are borrowed. Callers allocate/free output with the linked
engine module's `malloc`/`free`. Buffer functions return required byte lengths,
without NUL terminators; null output with zero capacity queries the size.
Insufficient capacity writes nothing. Negative error values are in the header.
Pointers and buffers must be valid, immutable/writable as appropriate, and
nonoverlapping. The adapter cannot validate a fabricated nonnull pointer.

Save format `jrogue.nethack.save` v1 accepts at most 16 MiB of opaque engine
payload, encoded as canonical lowercase hex. It binds release 5.0.0, official
commit `16ff59115315917b93185d026aeefea06db9b0f4`, and ABI
`nethack-shim-5.0.0-v1`. Restore validates the whole envelope before returning
payload bytes. CRC32 detects accidental corruption; it is not authentication.
The engine adapter must supply an actual valid save checkpoint and restore it
in a fresh compatible module. Native raw saves from other ABIs are incompatible.

Dependencies are exactly pinned to cached serde 1.0.229 and serde_json 1.0.151;
the lockfile pins transitive crates. Build/verification from `nethack/`:

```powershell
cargo fmt --manifest-path rust/Cargo.toml --check
cargo test --offline --manifest-path rust/Cargo.toml
cargo clippy --offline --manifest-path rust/Cargo.toml --all-targets -- -D warnings
cargo build --offline --manifest-path rust/Cargo.toml --release --lib --target wasm32-unknown-emscripten
```

The output `rust/target/wasm32-unknown-emscripten/release/libnethack_layers.a`
links directly into the official C engine module. The library contains no C/JS
imports. Tests cover adapter errors and input/text/save boundaries, not gameplay,
browser storage transactions, production hosting, or full Japanese translation.
Miri is recommended for CI over valid-pointer FFI tests when a compatible nightly
toolchain is available; no toolchain installation is required by this crate.

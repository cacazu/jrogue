//! Pure JSON localization. Formatting cannot call or mutate the game engine.

use std::collections::{BTreeMap, BTreeSet};
use std::fmt;

use serde::{Deserialize, Serialize};

use crate::domain::{MAX_ARGUMENTS, MAX_TEXT_BYTES, TextArgument, TextEvent, TextId};

/// Maximum JSON catalog size accepted at an adapter boundary.
pub const MAX_CATALOG_BYTES: usize = 16 * 1024 * 1024;
/// Maximum formatted UTF-8 bytes in a single text observation.
pub const MAX_RENDERED_BYTES: usize = 128 * 1024;

/// Japanese is the default presentation language.
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Locale {
    #[default]
    Ja,
    En,
}

/// Paired catalogs keyed by stable English semantic IDs.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Catalog {
    pub en: BTreeMap<TextId, String>,
    pub ja: BTreeMap<TextId, String>,
}

impl Catalog {
    /// Parse and validate a catalog, including matching argument schemas.
    ///
    /// # Errors
    /// Returns an error for oversized or malformed JSON, invalid templates,
    /// absent English source IDs, or mismatched EN/JA placeholders.
    pub fn from_json(json: &[u8]) -> Result<Self, FormatError> {
        if json.len() > MAX_CATALOG_BYTES {
            return Err(FormatError::TooLarge);
        }
        let catalog: Self = serde_json::from_slice(json).map_err(|_| FormatError::InvalidJson)?;
        for (id, english) in &catalog.en {
            let source_names = template_names(english)?;
            if let Some(japanese) = catalog.ja.get(id)
                && source_names != template_names(japanese)?
            {
                return Err(FormatError::ArgumentSchema);
            }
        }
        if catalog.ja.keys().any(|id| !catalog.en.contains_key(id)) {
            return Err(FormatError::MissingEnglish);
        }
        Ok(catalog)
    }

    fn template(&self, id: &TextId, locale: Locale) -> Result<(&str, bool), FormatError> {
        if locale == Locale::Ja
            && let Some(template) = self.ja.get(id)
        {
            return Ok((template, false));
        }
        self.en
            .get(id)
            .map(|template| (template.as_str(), locale == Locale::Ja))
            .ok_or(FormatError::MissingId)
    }

    /// Format a source-selected immutable event. Fallback is explicitly reported.
    ///
    /// # Errors
    /// Rejects missing IDs, invalid templates/arguments, reference cycles, and
    /// oversized text. It never substitutes an unvalidated format string.
    pub fn render(&self, event: &TextEvent, locale: Locale) -> Result<RenderedText, FormatError> {
        if event.args.len() > MAX_ARGUMENTS {
            return Err(FormatError::TooLarge);
        }
        let (template, fallback) = self.template(&event.id, locale)?;
        let expected = template_names(template)?;
        let supplied: BTreeSet<&str> = event.args.keys().map(String::as_str).collect();
        if expected != supplied {
            return Err(FormatError::ArgumentSchema);
        }
        let mut used_fallback = fallback;
        let text = substitute(template, |name| {
            let arg = event.args.get(name).ok_or(FormatError::ArgumentSchema)?;
            match arg {
                TextArgument::Text(text) => {
                    if text.len() > MAX_TEXT_BYTES {
                        return Err(FormatError::TooLarge);
                    }
                    Ok(text.clone())
                }
                TextArgument::Integer(value) => Ok(value.to_string()),
                TextArgument::Unsigned(value) => Ok(value.to_string()),
                TextArgument::Boolean(value) => Ok(value.to_string()),
                TextArgument::TextId(id) => self.resolve_reference(id, locale, &mut used_fallback),
            }
        })?;
        Ok(RenderedText {
            text,
            locale,
            used_fallback,
        })
    }

    fn resolve_reference(
        &self,
        id: &TextId,
        locale: Locale,
        used_fallback: &mut bool,
    ) -> Result<String, FormatError> {
        let (template, fallback) = self.template(id, locale)?;
        *used_fallback |= fallback;
        // Entity IDs are already-public names, not effect lookups. Their templates
        // deliberately carry no arguments; reference nesting is unsupported.
        if !template_names(template)?.is_empty() {
            return Err(FormatError::ArgumentSchema);
        }
        substitute(template, |_| Err(FormatError::ArgumentSchema))
    }
}

/// Rendering result keeps diagnostic coverage separate from visible text.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RenderedText {
    pub text: String,
    pub locale: Locale,
    pub used_fallback: bool,
}

/// Recoverable catalog/event errors.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FormatError {
    InvalidJson,
    MissingId,
    MissingEnglish,
    InvalidTemplate,
    ArgumentSchema,
    TooLarge,
}

impl fmt::Display for FormatError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(match self {
            Self::InvalidJson => "invalid localization JSON",
            Self::MissingId => "missing semantic text identifier",
            Self::MissingEnglish => "Japanese catalog identifier has no English source",
            Self::InvalidTemplate => "invalid localization template",
            Self::ArgumentSchema => "text arguments do not match template",
            Self::TooLarge => "localization text exceeds limits",
        })
    }
}

impl std::error::Error for FormatError {}

fn argument_name(name: &str) -> bool {
    let mut bytes = name.bytes();
    name.len() <= 64
        && matches!(bytes.next(), Some(b'a'..=b'z' | b'A'..=b'Z'))
        && bytes.all(|byte| byte.is_ascii_alphanumeric() || byte == b'_')
}

fn template_names(template: &str) -> Result<BTreeSet<&str>, FormatError> {
    if template.len() > MAX_TEXT_BYTES {
        return Err(FormatError::TooLarge);
    }
    let mut names = BTreeSet::new();
    visit_template(template, |name| {
        names.insert(name);
        Ok(String::new())
    })?;
    Ok(names)
}

fn substitute(
    template: &str,
    resolve: impl FnMut(&str) -> Result<String, FormatError>,
) -> Result<String, FormatError> {
    visit_template(template, resolve)
}

fn visit_template<'a>(
    template: &'a str,
    mut resolve: impl FnMut(&'a str) -> Result<String, FormatError>,
) -> Result<String, FormatError> {
    let mut output = String::with_capacity(template.len());
    let mut offset = 0;
    while offset < template.len() {
        let tail = &template[offset..];
        match tail.as_bytes()[0] {
            b'{' if tail.starts_with("{{") => {
                output.push('{');
                offset += 2;
            }
            b'}' if tail.starts_with("}}") => {
                output.push('}');
                offset += 2;
            }
            b'{' => {
                let end = tail.find('}').ok_or(FormatError::InvalidTemplate)?;
                let name = &tail[1..end];
                if !argument_name(name) {
                    return Err(FormatError::InvalidTemplate);
                }
                output.push_str(&resolve(name)?);
                offset += end + 1;
            }
            b'}' => return Err(FormatError::InvalidTemplate),
            _ => {
                let end = tail.find(['{', '}']).unwrap_or(tail.len());
                output.push_str(&tail[..end]);
                offset += end;
            }
        }
        if output.len() > MAX_RENDERED_BYTES {
            return Err(FormatError::TooLarge);
        }
    }
    Ok(output)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn catalog() -> Catalog {
        Catalog::from_json(r#"{"en":{"game.you_hit":"You hit {monster} for {damage}; {label}.","entity.orc":"orc","ui.only_english":"Source {{text}}"},"ja":{"game.you_hit":"{monster}に{damage}のダメージ。{label}。","entity.orc":"オーク"}}"#.as_bytes()).expect("test catalog")
    }

    #[test]
    fn japanese_typed_args_and_arbitrary_utf8_remain_literal() {
        let event: TextEvent = serde_json::from_str(r#"{"id":"game.you_hit","args":{"monster":{"type":"text_id","value":"entity.orc"},"damage":{"type":"integer","value":4},"label":{"type":"text","value":"100% {自由} 🐈"}}}"#).expect("test event");
        let rendered = catalog().render(&event, Locale::default()).expect("render");
        assert_eq!(rendered.text, "オークに4のダメージ。100% {自由} 🐈。");
        assert!(!rendered.used_fallback);
        assert_eq!(
            catalog().render(&event, Locale::En).expect("render").text,
            "You hit orc for 4; 100% {自由} 🐈."
        );
    }

    #[test]
    fn fallback_is_explicit_and_missing_ids_are_errors() {
        let event: TextEvent = serde_json::from_str(r#"{"id":"ui.only_english"}"#).expect("event");
        let rendered = catalog().render(&event, Locale::Ja).expect("fallback");
        assert_eq!(rendered.text, "Source {text}");
        assert!(rendered.used_fallback);
        let missing: TextEvent =
            serde_json::from_str(r#"{"id":"game.not_in_catalog"}"#).expect("event");
        assert_eq!(
            catalog().render(&missing, Locale::Ja),
            Err(FormatError::MissingId)
        );
    }

    #[test]
    fn invalid_templates_missing_or_extra_args_are_rejected() {
        assert_eq!(
            Catalog::from_json(br#"{"en":{"ui.test":"{count}"},"ja":{"ui.test":"{name}"}}"#)
                .unwrap_err(),
            FormatError::ArgumentSchema
        );
        assert_eq!(
            Catalog::from_json(br#"{"en":{"ui.test":"broken {"},"ja":{}}"#).unwrap_err(),
            FormatError::InvalidTemplate
        );
        let event: TextEvent = serde_json::from_str(
            r#"{"id":"ui.only_english","args":{"oops":{"type":"integer","value":1}}}"#,
        )
        .expect("event");
        assert_eq!(
            catalog().render(&event, Locale::Ja),
            Err(FormatError::ArgumentSchema)
        );
    }

    #[test]
    fn repeated_rendering_is_deterministic_without_mutating_events() {
        let event: TextEvent = serde_json::from_str(r#"{"id":"ui.only_english"}"#).expect("event");
        let before = event.clone();
        let catalog = catalog();
        for _ in 0..100 {
            assert_eq!(
                catalog.render(&event, Locale::Ja).expect("render").text,
                "Source {text}"
            );
        }
        assert_eq!(event, before);
    }
}

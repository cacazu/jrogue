/* NetHack browser adapter, changed 2026-10-02.
 * Distributed under the NetHack General Public License; see ../LICENSE. */
export const SOURCE_COMMIT = '16ff59115315917b93185d026aeefea06db9b0f4';
export const HOST_ABI = 'nethack-shim-5.0.0-v1';
export const COLORS = ['#777777','#ef6a6a','#6acb76','#cda15d','#719cfa','#d988ec','#62cbd3','#c5c8ce','#c5c8ce','#ffad57','#a3ec83','#f0d978','#9cb9ff','#f4a8ff','#9aeaf0','#ffffff'];

export function utf8Limit(value, capacity) {
  const encoder = new TextEncoder();
  let result = '';
  let used = 0;
  for (const char of String(value)) {
    const bytes = encoder.encode(char).length;
    if (used + bytes >= capacity) break;
    result += char;
    used += bytes;
  }
  return result;
}

/** A consumed input queue. Redraws have no reference to this queue. */
export class InputInbox {
  constructor() { this.queue = []; this.pending = null; this.consumed = []; this.consumedTotal = 0; }
  record(value) {
    this.consumedTotal++;
    this.consumed.push(value);
    if (this.consumed.length > 4096) this.consumed.splice(0,1024);
  }
  send(input) {
    const value = Object.freeze({ ...input });
    if (this.pending) {
      const resolve = this.pending;
      this.pending = null;
      this.record(value);
      resolve(value);
    } else if (this.queue.length < 256) this.queue.push(value);
    else return false;
    return true;
  }
  async read() {
    if (this.pending) throw new Error('Concurrent input wait is forbidden');
    if (this.queue.length) {
      const next = this.queue.shift();
      this.record(next);
      return next;
    }
    return new Promise(resolve => { this.pending = resolve; });
  }
  clear() { this.queue.length = 0; }
}

/** Thin memory adapter. Struct layouts come from compiled C, never guessed. */
export class EngineMemory {
  constructor(module, layout) {
    this.module = module;
    this.layout = layout;
    for (const key of ['anythingSize','menuItemSize','menuCountOffset','menuFlagsOffset']) {
      if (!Number.isInteger(layout[key]) || layout[key] <= 0) throw new Error(`Missing engine ABI layout: ${key}`);
    }
  }
  string(ptr) { return ptr ? this.module.UTF8ToString(ptr) : ''; }
  i32(ptr) { return this.module.getValue(ptr, 'i32'); }
  u32(ptr) { return this.i32(ptr) >>> 0; }
  writeString(ptr, text, capacity) {
    this.module.stringToUTF8(utf8Limit(text, capacity), ptr, capacity);
  }
  identifier(ptr) {
    return Array.from(this.module.HEAPU8.subarray(ptr, ptr + this.layout.anythingSize));
  }
  glyph(ptr) {
    if (!ptr) return Object.freeze({ glyph: -1, char: ' ', color: 7, flags: 0, frameColor: 0 });
    const l = this.layout;
    const code = this.u32(ptr + l.glyphCharOffset);
    return Object.freeze({ glyph: this.i32(ptr + l.glyphIdOffset), char: String.fromCodePoint(code <= 0x10ffff ? code : 32),
      color: this.i32(ptr + l.glyphColorOffset), flags: this.u32(ptr + l.glyphFlagsOffset),
      frameColor: this.u32(ptr + l.glyphFrameOffset), customColor: this.u32(ptr + l.glyphCustomColorOffset) });
  }
  menuResult(outputPtr, rows) {
    this.module.setValue(outputPtr, 0, '*');
    if (!rows.length) return 0;
    const l = this.layout;
    const ptr = this.module._malloc(rows.length * l.menuItemSize);
    if (!ptr) throw new Error('Could not allocate upstream menu result');
    this.module.HEAPU8.fill(0, ptr, ptr + rows.length * l.menuItemSize);
    rows.forEach((row, index) => {
      const entry = ptr + index * l.menuItemSize;
      this.module.HEAPU8.set(row.identifier, entry);
      this.module.setValue(entry + l.menuCountOffset, row.count ?? -1, 'i32');
      this.module.setValue(entry + l.menuFlagsOffset, row.flags, 'i32');
    });
    // Ownership passes to upstream; the game frees selected menu_item arrays.
    this.module.setValue(outputPtr, ptr, '*');
    return rows.length;
  }
  extendedCommands(pointer) {
    const l = this.layout;
    const rows = [];
    for (let index = 0; index < 1024; index++) {
      const entry = pointer + index * l.extCommandSize;
      const namePtr = this.i32(entry + l.extNameOffset);
      if (!namePtr) return rows;
      const flags = this.u32(entry + l.extFlagsOffset);
      // Same visibility mask as normal-mode upstream extended-command menus.
      if ((flags & (0x4 | 0x10 | 0x40)) === 0) {
        rows.push(Object.freeze({ index, name: this.string(namePtr), description: this.string(this.i32(entry + l.extDescriptionOffset)), flags }));
      }
    }
    throw new Error('Extended-command table is not terminated');
  }
}

/** Calls the pure Rust display/input layer; no gameplay functions are exposed. */
export class RustLayers {
  constructor(module, catalog) {
    this.module = module;
    this.catalogBytes = new TextEncoder().encode(JSON.stringify(catalog));
    this.catalogPtr = module._malloc(this.catalogBytes.length);
    module.HEAPU8.set(this.catalogBytes, this.catalogPtr);
  }
  withBytes(value, callback) {
    const bytes = new TextEncoder().encode(value);
    const ptr = this.module._malloc(Math.max(1, bytes.length));
    this.module.HEAPU8.set(bytes, ptr);
    try { return callback(ptr, bytes.length); } finally { this.module._free(ptr); }
  }
  format(id, args = {}, locale = 'ja') {
    const typed = Object.fromEntries(Object.entries(args).map(([key,value]) => [key,{type:Number.isInteger(value) ? 'integer' : 'text',value}]));
    return this.withBytes(JSON.stringify({ id, args: typed }), (eventPtr, eventLen) => {
      const params = [this.catalogPtr,this.catalogBytes.length,eventPtr,eventLen,locale === 'en' ? 1 : 0,0,0];
      const size = this.module.ccall('nh_rust_format','number',Array(7).fill('number'),params);
      if (size < 0 || size > 1048576) throw new Error(`Rust presentation rejected ${id}: ${size}`);
      const output = this.module._malloc(size + 1);
      try {
        params[5] = output; params[6] = size;
        const written = this.module.ccall('nh_rust_format','number',Array(7).fill('number'),params);
        if (written !== size) throw new Error('Rust presentation length mismatch');
        return new TextDecoder('utf-8',{fatal:true}).decode(this.module.HEAPU8.subarray(output,output+size));
      } finally { this.module._free(output); }
    });
  }
  keycode(key, modifiers, context = 0) {
    return this.withBytes(key,(ptr,len) => this.module.ccall('nh_rust_keycode','number',Array(4).fill('number'),[ptr,len,modifiers,context]));
  }
  direction(dx,dy,run = false,context = 0,layout = 0) {
    return this.module.ccall('nh_rust_direction_pad','number',Array(5).fill('number'),[dx,dy,run ? 1 : 0,context,Number(layout)]);
  }
  textInsert(text) {
    return this.withBytes(text,(ptr,len) => {
      const params = [ptr,len,4,0,0];
      const size = this.module.ccall('nh_rust_text_insert','number',Array(5).fill('number'),params);
      if (size < 0 || size > 1048576) throw new Error(`Invalid text input (${size})`);
      const output = this.module._malloc(Math.max(1,size));
      try {
        params[3] = output; params[4] = size;
        const written = this.module.ccall('nh_rust_text_insert','number',Array(5).fill('number'),params);
        if (written !== size) throw new Error('Text input length mismatch');
        return new TextDecoder('utf-8',{fatal:true}).decode(this.module.HEAPU8.subarray(output,output+size));
      } finally { this.module._free(output); }
    });
  }
}

export const SHIM_CALLBACKS = Object.freeze([
  'shim_init_nhwindows','shim_player_selection_or_tty','shim_askname','shim_get_nh_event',
  'shim_exit_nhwindows','shim_suspend_nhwindows','shim_resume_nhwindows','shim_create_nhwindow',
  'shim_clear_nhwindow','shim_display_nhwindow','shim_destroy_nhwindow','shim_curs','shim_putstr',
  'shim_display_file','shim_start_menu','shim_add_menu','shim_end_menu','shim_select_menu',
  'shim_message_menu','shim_mark_synch','shim_wait_synch','shim_cliparound','shim_update_positionbar',
  'shim_print_glyph','shim_raw_print','shim_raw_print_bold','shim_nhgetch','shim_nh_poskey',
  'shim_nhbell','shim_doprev_message','shim_yn_function','shim_getlin','shim_get_ext_cmd',
  'shim_number_pad','shim_delay_output','shim_change_color','shim_change_background','set_shim_font_name',
  'shim_get_color_string','shim_preference_update','shim_getmsghistory','shim_putmsghistory',
  'shim_status_init','shim_status_enablefield','shim_status_update'
]);

/** Full official windowport adapter. UI methods resolve only after real user input. */
export class ShimHost {
  constructor({ module, layout, ui, globals = () => globalThis.nethackGlobal, fileReader, persist = async () => {} }) {
    this.module = module;
    this.memory = new EngineMemory(module,layout);
    this.ui = ui;
    this.global = globals;
    this.fileReader = fileReader;
    this.persist = persist;
    this.inbox = new InputInbox();
    this.windows = new Map();
    this.nextWindow = 1;
    this.history = [];
    this.historyCursor = 0;
    this.status = new Map();
    this.map = new Map();
    this.pendingKind = null;
    this.exited = false;
    this.windowClosed = false;
    this.finalization = null;
    this.numberPad = false;
    this.inputLayout = 0;
    this.trace = [];
    this.missingSemanticTexts = 0;
    this.callback = this.callback.bind(this);
  }
  window(id) {
    const win = this.windows.get(id);
    if (!win) throw new Error(`Unknown upstream window ${id}`);
    return win;
  }
  finalize(status = 0) {
    if (!this.finalization) this.finalization = (async () => {
      try { if (status === 0) await this.persist(); }
      finally {
        this.exited = true;
        this.pendingKind = null;
        this.inbox.clear();
        this.ui.exited();
      }
    })();
    return this.finalization;
  }
  gameText(text, channel = 'game') {
    // Explicit unlocalized upstream surface. Never infer semantic IDs from English.
    const event = Object.freeze({ id:'upstream.untranslated',args:Object.freeze({text:String(text)}),channel,translated:false });
    this.missingSemanticTexts++;
    return event;
  }
  message(text, attr = 0) {
    if (!text) return;
    const event = this.gameText(text,'message');
    this.history.push(event);
    if (this.history.length > 1000) this.history.shift();
    this.ui.message(event,attr);
  }
  async wait(kind, operation) {
    if (this.pendingKind) throw new Error(`Reentrant UI wait: ${kind} during ${this.pendingKind}`);
    this.pendingKind = kind;
    this.ui.waiting(kind);
    try { return await operation(); }
    finally { this.pendingKind = null; this.ui.waiting(null); }
  }
  async readKey(kind = 'key') {
    return this.wait(kind,async () => {
      while (true) {
        const input = await this.inbox.read();
        if (input.type === 'key') return input.code;
      }
    });
  }
  frame() {
    return Object.freeze({ cells:Object.freeze(Array.from(this.map.values())),status:Object.freeze(Array.from(this.status.values())) });
  }
  redraw() { this.ui.frame(this.frame()); }
  async callback(name,...args) {
    this.trace.push(name);
    if (this.trace.length > 2000) this.trace.shift();
    switch (name) {
    case 'shim_init_nhwindows': {
      this.global().globals.iflags.window_inited = true;
      this.ui.initialized(); return;
    }
    case 'shim_player_selection_or_tty': return true; // Official genl_player_setup rules and menus.
    case 'shim_askname': {
      const name = await this.wait('text',() => this.ui.text({id:'ui.player_name',maxBytes:this.memory.layout.playerNameSize}));
      this.global().globals.svp.plname = utf8Limit(name ?? 'Player',this.memory.layout.playerNameSize);
      return;
    }
    case 'shim_create_nhwindow': {
      const id = this.nextWindow++;
      this.windows.set(id,{id,type:args[0],lines:[],items:[],prompt:'',behavior:0}); return id;
    }
    case 'shim_clear_nhwindow': {
      const win = this.window(args[0]); win.lines = []; win.items = [];
      if (win.type === 3) { this.map.clear(); this.redraw(); }
      if (win.type === 1) this.ui.clearMessage?.(); return;
    }
    case 'shim_destroy_nhwindow': this.windows.delete(args[0]); return;
    case 'shim_curs': {
      this.window(args[0]).cursor = Object.freeze({x:args[1],y:args[2]});
      if (this.window(args[0]).type === 3) this.ui.cursor?.(args[1],args[2]); return;
    }
    case 'shim_putstr': {
      const [id,attr,text] = args;
      const win = this.window(id);
      if (win.type === 1) this.message(text,attr);
      else if (win.type === 2) this.ui.statusText?.(this.gameText(text,'status'));
      else win.lines.push(Object.freeze({event:this.gameText(text,'window'),attr}));
      return;
    }
    case 'shim_display_nhwindow': {
      const [id,blocking] = args; const win = this.window(id);
      this.redraw();
      if (win.type === 4 || win.type === 5) {
        await this.wait('display',() => this.ui.document({title:win.prompt,lines:win.lines,items:win.items}));
      } else if (blocking) await this.wait('more',() => this.ui.more());
      return;
    }
    case 'shim_display_file': {
      const [filename,complain] = args;
      try {
        const content = await this.fileReader(filename);
        const lines = content.split(/\r?\n/).map(text => Object.freeze({event:this.gameText(text,'file'),attr:0}));
        await this.wait('display',() => this.ui.document({title:filename,lines,items:[]}));
      } catch (error) { if (complain) this.message(`Cannot open ${filename}: ${error.message}`); }
      return;
    }
    case 'shim_start_menu': {
      const win = this.window(args[0]); win.lines = []; win.items = []; win.behavior = args[1]; return;
    }
    case 'shim_add_menu': {
      const [id,glyphPtr,identifierPtr,ch,gch,attr,color,text,flags] = args;
      const identifier = this.memory.identifier(identifierPtr);
      // Native ports define selectability by a_void (a wasm32 pointer), even
      // though this release enlarged anything to eight bytes for 64-bit data.
      this.window(id).items.push(Object.freeze({identifier:Object.freeze(identifier),selectable:this.memory.i32(identifierPtr) !== 0,
        glyph:this.memory.glyph(glyphPtr),accelerator:ch & 255,groupAccelerator:gch & 255,attr,color,
        event:this.gameText(text,'menu'),flags,selected:!!(flags & 1)})); return;
    }
    case 'shim_end_menu': this.window(args[0]).prompt = args[1]; return;
    case 'shim_select_menu': {
      const [id,how,outputPtr] = args;
      this.module.setValue(outputPtr,0,'*');
      const win = this.window(id);
      const selection = await this.wait('menu',() => this.ui.menu({how,prompt:this.gameText(win.prompt,'menu_prompt'),items:win.items,lines:win.lines}));
      if (selection === null) return -1;
      if (how === 0) return 0;
      if (how === 1 && selection.length > 1) throw new Error('PICK_ONE returned multiple items');
      const rows = selection.map(({index,count}) => {
        const item = win.items[index];
        if (!item?.selectable || (count !== -1 && (!Number.isInteger(count) || count < 1 || count > 2147483647))) throw new Error('Invalid menu selection');
        return {...item,count};
      });
      return this.memory.menuResult(outputPtr,rows);
    }
    case 'shim_message_menu': {
      const [letter,how,text] = args;
      this.message(text);
      const code = await this.wait('more',() => this.ui.more());
      return how === 0 ? 0 : code === (letter & 255) ? (letter & 255) : 0;
    }
    case 'shim_print_glyph': {
      const [,x,y,ptr,bgPtr] = args;
      if (x > 0 && x < 80 && y >= 0 && y < 21) {
        this.map.set(`${x},${y}`,Object.freeze({x,y,...this.memory.glyph(ptr),background:this.memory.glyph(bgPtr)}));
      }
      this.ui.dirty?.(); return;
    }
    case 'shim_raw_print': this.message(args[0]); return;
    case 'shim_raw_print_bold': this.message(args[0],1); return;
    case 'shim_nhgetch': this.redraw(); return this.readKey();
    case 'shim_nh_poskey': {
      const [xp,yp,mp] = args; this.redraw();
      const inputState = this.module.ccall('nh_abi_input_state','number',[],[]);
      return this.wait(inputState === 1 ? 'command' : 'position',async () => {
        const input = await this.inbox.read();
        if (input.type === 'click') {
          this.module.setValue(xp,input.x,'i16'); this.module.setValue(yp,input.y,'i16'); this.module.setValue(mp,input.mod ?? 1,'i32'); return 0;
        }
        return input.code;
      });
    }
    case 'shim_yn_function': {
      const [query,responses,def] = args;
      const response = await this.wait('question',() => this.ui.question({prompt:this.gameText(query,'question'),responses,defaultCode:def & 255}));
      if (typeof response === 'object' && response !== null) {
        if (response.code !== 35 || !Number.isInteger(response.count) || response.count < 0 || response.count > 2147483647) throw new Error('Invalid numeric question response');
        this.module.ccall('nh_abi_set_yn_number',null,['number'],[response.count]);
        return response.code;
      }
      return response;
    }
    case 'shim_getlin': {
      const [query,ptr] = args;
      const text = await this.wait('text',() => this.ui.text({prompt:this.gameText(query,'getlin'),maxBytes:this.memory.layout.lineBufferSize}));
      this.memory.writeString(ptr,text === null ? '\u001b' : text,this.memory.layout.lineBufferSize); return;
    }
    case 'shim_get_ext_cmd': {
      const commands = this.memory.extendedCommands(this.global().pointers.extcmdlist);
      return this.wait('extended',() => this.ui.extended(commands));
    }
    case 'shim_getmsghistory': {
      if (args[0]) this.historyCursor = 0;
      return this.history[this.historyCursor++]?.args.text ?? null;
    }
    case 'shim_putmsghistory': {
      const [text] = args;
      if (text) { this.history.push(this.gameText(text,'message')); if (this.history.length > 1000) this.history.shift(); }
      return;
    }
    case 'shim_doprev_message': await this.wait('history',() => this.ui.history(this.history)); return 0;
    case 'shim_status_init': this.status.clear(); return;
    case 'shim_status_enablefield': {
      const [index,namePtr,formatPtr,enabled] = args;
      this.status.set(index,Object.freeze({index,name:this.memory.string(namePtr),format:this.memory.string(formatPtr),enabled,value:''})); return;
    }
    case 'shim_status_update': {
      const [index,ptr,change,percent,color,masksPtr] = args;
      if (index < 0) { this.redraw(); return; }
      const old = this.status.get(index) ?? {index,name:'',enabled:true};
      const conditionIndex = this.global().constants.STATUS_FIELD.BL_CONDITION;
      const condition = index === conditionIndex;
      const value = condition ? this.memory.u32(ptr) : this.memory.string(ptr);
      const masks = condition && masksPtr ? Array.from({length:24},(_,i) => this.memory.u32(masksPtr+i*4)) : [];
      this.status.set(index,Object.freeze({...old,value,condition,color,change,percent,masks:Object.freeze(masks)})); return;
    }
    case 'shim_exit_nhwindows': {
      // NetHack may still append scores after closing its windows.
      // Only the final native exit can complete browser persistence.
      this.windowClosed = true; this.inbox.clear();
      if (args[0]) this.message(args[0]);
      return;
    }
    case 'shim_suspend_nhwindows': if (args[0]) this.message(args[0]); this.ui.suspended?.(); return;
    case 'shim_resume_nhwindows': this.redraw(); return;
    case 'shim_cliparound': this.ui.clip?.(args[0],args[1]); return;
    case 'shim_update_positionbar': this.ui.positionbar?.(args[0]); return;
    case 'shim_number_pad': this.numberPad = args[0] !== 0; this.inputLayout = this.module.ccall('nh_abi_input_layout','number',[],[]); this.ui.numberPad?.(this.numberPad); return;
    case 'shim_nhbell': this.ui.bell?.(); return;
    case 'shim_delay_output': await this.ui.delay?.(); return;
    case 'shim_change_color': this.ui.color?.(...args); return;
    case 'shim_change_background': this.ui.background?.(...args); return;
    case 'set_shim_font_name': this.ui.font?.(...args); return 0;
    case 'shim_get_color_string': return '';
    case 'shim_mark_synch': case 'shim_wait_synch': this.redraw(); return;
    case 'shim_get_nh_event': case 'shim_preference_update': return;
    default: throw new Error(`Unsupported upstream callback: ${name}`);
    }
  }
}

export function readGameFile(FS,filename,gameDir = '/nethack') {
  if (!/^[A-Za-z0-9_.-]+$/.test(filename)) throw new Error('Invalid game data filename');
  for (const path of [`${gameDir}/${filename}`,`${gameDir}/dat/${filename}`]) {
    try { return FS.readFile(path,{encoding:'utf8'}); } catch { /* Try next explicit game-data path. */ }
  }
  throw new Error('Game data file was not preloaded');
}

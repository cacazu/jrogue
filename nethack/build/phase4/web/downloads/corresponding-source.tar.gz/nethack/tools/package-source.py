"""Package complete corresponding source for the built browser engine.

New integration script, 2026-10-02; distributed under the NGPL (see notices).
Unused source sound samples are excluded from distribution, with notices kept.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "web" / "downloads" / "corresponding-source.tar.gz")
    args = parser.parse_args()
    modified = ROOT / "work" / "NetHack-5.0.0"
    lua = modified / "lib" / "lua-5.4.8"
    if not modified.exists() or not lua.exists():
        raise SystemExit("build the real engine first; modified source and pinned Lua are required")
    required = [ROOT / "provenance.json", ROOT / "build" / "engine-manifest.json", ROOT / "rust" / "Cargo.lock"]
    if not all(x.is_file() for x in required):
        raise SystemExit("source provenance, actual engine manifest and locked Rust dependencies are required")
    members: list[tuple[Path, str]] = []
    for directory in ("tools", "docs", "rust", "web", "catalog", "locales", "licenses", "tests"):
        for p in sorted((ROOT / directory).rglob("*")):
            if not p.is_file() or any(x in p.parts for x in ("target", "downloads", "node_modules", ".sites-runtime", "results", "__pycache__")):
                continue
            if p.suffix in (".wasm", ".data", ".save", ".save.json"):
                continue
            members.append((p, "nethack/" + p.relative_to(ROOT).as_posix()))
    for tree, archive_prefix in ((ROOT / "upstream" / "NetHack-5.0.0", "nethack/upstream/NetHack-5.0.0/"), (modified, "nethack/engine-source/")):
        for p in sorted(tree.rglob("*")):
            if not p.is_file() or "obj" in p.parts or "native" in p.parts:
                continue
            if p.suffix.lower() in (".wav", ".uu", ".o", ".obj", ".exe", ".dll", ".a", ".lib") and p.name != "Makefile.lib":
                continue
            members.append((p, archive_prefix + p.relative_to(tree).as_posix()))
    for filename in ("README.md", "THIRD-PARTY-NOTICES.md", "provenance.json", "verification.json", ".gitignore"):
        p = ROOT / filename
        if p.is_file():
            members.append((p, "nethack/" + filename))
    for p in sorted((ROOT / "build").glob("*.json")):
        if p.name == "source-check-report.json":
            continue
        members.append((p, "nethack/build/" + p.name))
    for p in sorted((ROOT / "build").glob("*.patch")):
        members.append((p, "nethack/build/" + p.name))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(args.output, "w:gz") as archive:
        for p, name in members:
            info = archive.gettarinfo(str(p), arcname=name)
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            with p.open("rb") as stream:
                archive.addfile(info, stream)
    with tarfile.open(args.output) as archive:
        names = set(archive.getnames())
        for expected in ("nethack/upstream/NetHack-5.0.0/dat/license", "nethack/engine-source/dat/license", "nethack/engine-source/lib/lua-5.4.8/src/lua.h", "nethack/rust/Cargo.lock", "nethack/tools/build-upstream.py"):
            if expected not in names:
                raise SystemExit(f"missing required corresponding source: {expected}")
    with args.output.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    print(json.dumps({"result": "pass", "file": str(args.output), "files": len(members), "bytes": args.output.stat().st_size, "sha256": digest, "excluded": "unused sound recordings and compiled build tools"}))


if __name__ == "__main__":
    main()

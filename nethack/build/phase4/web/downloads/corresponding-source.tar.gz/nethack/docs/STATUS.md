# Verified delivery status

Updated 2026-10-02. This status is deliberately separate from the source-derived inventories.

The implementation preserves the complete official NetHack 5.0.0 C game. Rust separates presentation, input/application commands and platform adapters, following the user's explicit clarification. It does not rewrite the gameplay in Rust. Original source, modified build source, Lua, locked Rust dependencies and notices are retained.

## Completed

- Official release archive pinned to commit `16ff59115315917b93185d026aeefea06db9b0f4`; all 1,265 original files checked against the official archive.
- Complete C/Lua WASM engine compiled and linked with the Rust static library. The official DLB reader verifies every packaged runtime asset. The browser now enters a real dungeon with map, status and original turn processing.
- Rust presentation/input/save contract: 24 native tests passed, formatting and strict Clippy passed. All 11 exact dependency sources and original notices are vendored; native tests also pass with `--offline --locked`.
- Browser host implements the original window callbacks, menus, prompts, map, status, help, raw commands and native save-and-quit boundary. All 29 boundary checks pass (23 host checks and 6 calls to the actual compiled Rust/C ABI).
- Actual Chrome checks pass for all 13 official role starts, normal native adventure, map/status, real wait/movement turns, inventory/help/prompts, 100 pure locale/repaint operations, fresh 390x844 touch startup, mobile directions/raw entry, native save-and-quit and a fresh WASM instance restoring measured hero/current-level fields and visible glyphs. Full campaign branches and endgame have not been exhaustively played.
- Local score/history and native committed bones have a strict source-derived file allowlist and an atomic browser storage boundary at final native exit. Actual native quit writes nonempty logfile/xlogfile, and their exact bytes survive a fresh Knight adventure. A legitimate zero-score run leaves record empty. No actual death/bones creation/consumption integration success is claimed.
- Final bounded Chrome suite: **17/17 passed**, server checks **4/4 passed**, zero unexpected browser errors. One owned browser/server ran only after fresh physical/commit headroom checks exceeded the parent's 2 GiB thresholds. All owned processes exited after 25.639 seconds; no new linker/compiler was run.
- Full source-derived mechanics and text inventories exist. The scanner's seven focused tests pass. Counts are lexical candidates, not claims of runtime translation completeness.
- Japanese interface is the default; interface messages use semantic IDs and typed arguments through the actual Rust formatter.
- 483 source-backed English/Japanese game-message seed pairs are validated against 492 source call sites. They are not yet connected to the original gameplay producers. Of these, 65 require future semantic localization of argument values.

## Remaining checks before publication

The complete frozen-bundle browser run is passed and all NetHack jobs are drained. The final corresponding-source download must be rebound to the exact final artifact hashes; the candidate archive passed 14 independent source/runtime/license/offline preparation checks. Private Sites publication is next. Native deployment status must reach terminal success before a live URL is reported.

## Translation phase still open

Game prose remains the original English. The page says: **画面操作は日本語、ゲーム本文は英語です。** Full Japanese gameplay is not complete. The inventory contains 6,674 literal message-format candidates and 1,167 dynamic/macro candidates, plus Lua/data/document text surfaces and intermediate formatting calls. Source seed translations alone do not provide runtime coverage.

The remaining phase must instrument the original message producers to emit accepted semantic IDs and typed arguments, preserve knowledge-sensitive object/monster names, cover dynamic strings and data text, and validate the complete Japanese catalogs. Rendering and locale changes must remain pure and must not consume game RNG or advance turns.

The Site is registered as owner-private but has not yet been published. No other game project or shared root Git state is changed by this work.

//! Pure SHA-256 for owned replay evidence. No clock, state lookup or I/O.

const K: [u32; 64] = [
 0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
 0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
 0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
 0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
 0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
 0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
 0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
 0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2,
];
struct Sha256 { state:[u32;8], block:[u8;64], used:usize, bytes:u64 }
impl Sha256 {
 fn new()->Self { Self { state:[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
  0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19],block:[0;64],used:0,bytes:0 } }
 fn compress(&mut self) {
  let mut w=[0u32;64];
  for (i,chunk) in self.block.chunks_exact(4).enumerate() {
   w[i]=u32::from_be_bytes([chunk[0],chunk[1],chunk[2],chunk[3]]);
  }
  for i in 16..64 {
   let s0=w[i-15].rotate_right(7)^w[i-15].rotate_right(18)^(w[i-15]>>3);
   let s1=w[i-2].rotate_right(17)^w[i-2].rotate_right(19)^(w[i-2]>>10);
   w[i]=w[i-16].wrapping_add(s0).wrapping_add(w[i-7]).wrapping_add(s1);
  }
  let [mut a,mut b,mut c,mut d,mut e,mut f,mut g,mut h]=self.state;
  for i in 0..64 {
   let s1=e.rotate_right(6)^e.rotate_right(11)^e.rotate_right(25);
   let choice=(e&f)^(!e&g);
   let t1=h.wrapping_add(s1).wrapping_add(choice).wrapping_add(K[i]).wrapping_add(w[i]);
   let s0=a.rotate_right(2)^a.rotate_right(13)^a.rotate_right(22);
   let majority=(a&b)^(a&c)^(b&c);
   let t2=s0.wrapping_add(majority);
   h=g;g=f;f=e;e=d.wrapping_add(t1);d=c;c=b;b=a;a=t1.wrapping_add(t2);
  }
  for (state,value) in self.state.iter_mut().zip([a,b,c,d,e,f,g,h]) {*state=state.wrapping_add(value);}
 }
 fn update(&mut self,bytes:&[u8]) {
  self.bytes=self.bytes.wrapping_add(bytes.len() as u64);
  for &byte in bytes {
   self.block[self.used]=byte;self.used+=1;
   if self.used==64 {self.compress();self.used=0;}
  }
 }
 fn finish(mut self)->[u8;32] {
  let bits=self.bytes.wrapping_mul(8);
  self.update(&[0x80]);while self.used!=56 {self.update(&[0]);}
  self.update(&bits.to_be_bytes());
  let mut output=[0;32];
  for (chunk,value) in output.chunks_exact_mut(4).zip(self.state) {chunk.copy_from_slice(&value.to_be_bytes());}
  output
 }
}
pub(crate) fn sha256(parts:&[&[u8]])->[u8;32] {
 let mut hash=Sha256::new();for part in parts {hash.update(part);}hash.finish()
}
#[cfg(test)] mod tests {
 use super::*;
 fn hex(bytes:[u8;32])->String {bytes.iter().map(|byte|format!("{byte:02x}")).collect()}
 #[test] fn published_vectors_and_arbitrary_chunk_boundaries_match() {
  assert_eq!(hex(sha256(&[b""])),"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
  assert_eq!(hex(sha256(&[b"a",b"",b"bc"])),"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
  assert_eq!(hex(sha256(&[b"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"])),"248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1");
  let million=vec![b'a';1_000_000];
  assert_eq!(hex(sha256(&[&million])),"cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0");
  let bytes:Vec<u8>=(0..255).collect();
  for split in 0..=bytes.len() {assert_eq!(sha256(&[&bytes]),sha256(&[&bytes[..split],&bytes[split..]]));}
 }
}

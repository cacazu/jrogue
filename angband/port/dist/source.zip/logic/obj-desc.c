/**
 * \file obj-desc.c
 * \brief Create object name descriptions
 *
 * Copyright (c) 1997 - 2007 Angband contributors
 *
 * This work is free software; you can redistribute it and/or modify it
 * under the terms of either:
 *
 * a) the GNU General Public License as published by the Free Software
 *    Foundation, version 2, or
 *
 * b) the "Angband licence":
 *    This software may be copied and distributed for educational, research,
 *    and not for profit purposes provided that this copyright and statement
 *    are included in all such copies.  Other copyrights may also apply.
 */

#include "angband.h"
#include "obj-chest.h"
#include "obj-desc.h"
#include "obj-gear.h"
#include "obj-ignore.h"
#include "obj-knowledge.h"
#include "obj-tval.h"
#include "obj-util.h"/* AB_NAMING_BEGIN */
#include "web-naming.h"/* AB_NAMING_END */

/**
 * Puts the object base kind's name into buf.
 */
void object_base_name(char *buf, size_t max, int tval, bool plural)
{
	/* AB_NAMING_BEGIN */
#ifdef __EMSCRIPTEN__
	struct ab_naming_session ab_naming_capture;
	ab_naming_object_base_begin(&ab_naming_capture, buf, max);
#endif
	/* AB_NAMING_END */struct object_base *kb = &kb_info[tval];
	size_t end = 0;

	if (kb->name && kb->name[0]) 
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_object_base_name(tval, plural)), /* AB_NAMING_END */(void) obj_desc_name_format(buf, max, end, kb->name, NULL, plural);
/* AB_NAMING_BEGIN */	AB_NAMING_CAPTURE(ab_naming_object_finish(0));
/* AB_NAMING_END */}


/**
 * Puts a very stripped-down version of an object's name into buf.
 * If easy_know is true, then the IDed names are used, otherwise
 * flavours, scroll names, etc will be used.
 *
 * Just truncates if the buffer isn't big enough.
 */
void object_kind_name(char *buf, size_t max, const struct object_kind *kind,
					  bool easy_know)
{
	/* AB_NAMING_BEGIN */
#ifdef __EMSCRIPTEN__
	struct ab_naming_session ab_naming_capture;
	ab_naming_object_kind_begin(&ab_naming_capture, buf, max, kind);
#endif
	/* AB_NAMING_END *//* If not aware, the plain flavour (e.g. Copper) will do. */
	if (!easy_know && !kind->aware && kind->flavor)
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_object_flavor(kind)), /* AB_NAMING_END */my_strcpy(buf, kind->flavor->text, max);

	/* Use proper name (Healing, or whatever) */
	else
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE((ab_naming_select_kind_base(kind), ab_naming_object_base(kind, NULL, false))), /* AB_NAMING_END */(void) obj_desc_name_format(buf, max, 0, kind->name, NULL, false);
/* AB_NAMING_BEGIN */	AB_NAMING_CAPTURE(ab_naming_object_finish(0));
/* AB_NAMING_END */}


/**
 * A modifier string, put where '#' goes in the basename below.  The weird
 * games played with book names are to allow the non-essential part of the
 * name to be abbreviated when there is not much room to display.
 */
static const char *obj_desc_get_modstr(const struct object_kind *kind)
{
	if (tval_can_have_flavor_k(kind))
		return kind->flavor ? kind->flavor->text : "";

	if (tval_is_book_k(kind))
		return kind->name;

	return "";
}

/**
 * An object's basic name - a generic name for flavored objects (with the
 * actual name added later depending on awareness, the name from object.txt
 * for almost everything else, and a bit extra for books. 
 */
static const char *obj_desc_get_basename(const struct object *obj, bool aware,
		bool terse, uint32_t mode, const struct player *p)
{
	bool show_flavor = !terse && obj->kind->flavor;

	if (mode & ODESC_STORE)
		show_flavor = false;
	if (aware && p && !OPT(p, show_flavors)) show_flavor = false;

	/* Artifacts are special */
	if (obj->artifact && (aware || object_is_known_artifact(obj) || terse ||
						  !obj->kind->flavor))
		return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_kind_base(obj->kind)), /* AB_NAMING_END */obj->kind->name/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;

	/* Analyze the object */
	switch (obj->tval)
	{
		case TV_FLASK:
		case TV_CHEST:
		case TV_SHOT:
		case TV_BOLT:
		case TV_ARROW:
		case TV_BOW:
		case TV_HAFTED:
		case TV_POLEARM:
		case TV_SWORD:
		case TV_DIGGING:
		case TV_BOOTS:
		case TV_GLOVES:
		case TV_CLOAK:
		case TV_CROWN:
		case TV_HELM:
		case TV_SHIELD:
		case TV_SOFT_ARMOR:
		case TV_HARD_ARMOR:
		case TV_DRAG_ARMOR:
		case TV_LIGHT:
		case TV_FOOD:
			return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_kind_base(obj->kind)), /* AB_NAMING_END */obj->kind->name/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;

		case TV_AMULET:
			return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base(show_flavor ? "object.basename.amulet.flavored" : "object.basename.amulet.plain")), /* AB_NAMING_END */(show_flavor ? "& # Amulet~" : "& Amulet~")/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;

		case TV_RING:
			return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base(show_flavor ? "object.basename.ring.flavored" : "object.basename.ring.plain")), /* AB_NAMING_END */(show_flavor ? "& # Ring~" : "& Ring~")/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;

		case TV_STAFF:
			return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base(show_flavor ? "object.basename.staff.flavored" : "object.basename.staff.plain")), /* AB_NAMING_END */(show_flavor ? "& # Sta|ff|ves|" : "& Sta|ff|ves|")/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;

		case TV_WAND:
			return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base(show_flavor ? "object.basename.wand.flavored" : "object.basename.wand.plain")), /* AB_NAMING_END */(show_flavor ? "& # Wand~" : "& Wand~")/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;

		case TV_ROD:
			return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base(show_flavor ? "object.basename.rod.flavored" : "object.basename.rod.plain")), /* AB_NAMING_END */(show_flavor ? "& # Rod~" : "& Rod~")/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;

		case TV_POTION:
			return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base(show_flavor ? "object.basename.potion.flavored" : "object.basename.potion.plain")), /* AB_NAMING_END */(show_flavor ? "& # Potion~" : "& Potion~")/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;

		case TV_SCROLL:
			return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base(show_flavor ? "object.basename.scroll.flavored" : "object.basename.scroll.plain")), /* AB_NAMING_END */(show_flavor ? "& Scroll~ titled #" : "& Scroll~")/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;

		case TV_MAGIC_BOOK:
			if (terse)
				return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base("object.basename.magic_book.terse")), /* AB_NAMING_END */"& Book~ #"/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;
			else
				return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base("object.basename.magic_book.full")), /* AB_NAMING_END */"& Book~ of Magic Spells #"/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;

		case TV_PRAYER_BOOK:
			if (terse)
				return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base("object.basename.prayer_book.terse")), /* AB_NAMING_END */"& Book~ #"/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;
			else
				return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base("object.basename.prayer_book.full")), /* AB_NAMING_END */"& Holy Book~ of Prayers #"/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;

		case TV_NATURE_BOOK:
			if (terse)
				return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base("object.basename.nature_book.terse")), /* AB_NAMING_END */"& Book~ #"/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;
			else
				return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base("object.basename.nature_book.full")), /* AB_NAMING_END */"& Book~ of Nature Magics #"/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;

		case TV_SHADOW_BOOK:
			if (terse)
				return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base("object.basename.shadow_book.terse")), /* AB_NAMING_END */"& Tome~ #"/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;
			else
				return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base("object.basename.shadow_book.full")), /* AB_NAMING_END */"& Necromantic Tome~ #"/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;

		case TV_OTHER_BOOK:
			if (terse)
				return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base("object.basename.other_book.terse")), /* AB_NAMING_END */"& Book~ #"/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;
			else
				return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base("object.basename.other_book.full")), /* AB_NAMING_END */"& Book of Mysteries~ #"/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;

		case TV_MUSHROOM:
			return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base(show_flavor ? "object.basename.mushroom.flavored" : "object.basename.mushroom.plain")), /* AB_NAMING_END */(show_flavor ? "& # Mushroom~" : "& Mushroom~")/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;
	}

	return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_select_base("object.nothing")), /* AB_NAMING_END */"(nothing)"/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;
}


/**
 * Start to description, indicating number/uniqueness (a, the, no more, 7, etc)
 */
static size_t obj_desc_name_prefix(char *buf, size_t max, size_t end,
		const struct object *obj, const char *basename,
		const char *modstr, bool terse, uint16_t number)
{
	if (number == 0) {
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_object_prefix("no_more", 0)), /* AB_NAMING_END */strnfcat(buf, max, &end, "no more ");
	} else if (number > 1) {
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_object_prefix("quantity", number)), /* AB_NAMING_END */strnfcat(buf, max, &end, "%u ", number);
	} else if (object_is_known_artifact(obj)) {
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_object_prefix("the", 1)), /* AB_NAMING_END */strnfcat(buf, max, &end, "the ");
	} else if (*basename == '&') {
		bool an = false;
		const char *lookahead = basename + 1;

		while (*lookahead == ' ') lookahead++;

		if (*lookahead == '#') {
			if (modstr && is_a_vowel(*modstr))
				an = true;
		} else if (is_a_vowel(*lookahead)) {
			an = true;
		}

		if (!terse) {
			if (an)
				/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_object_prefix("an", 1)), /* AB_NAMING_END */strnfcat(buf, max, &end, "an ");
			else
				/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_object_prefix("a", 1)), /* AB_NAMING_END */strnfcat(buf, max, &end, "a ");			
		}
	}

	return end;
}



/**
 * Formats 'fmt' into 'buf', with the following formatting characters:
 *
 * '~' at the end of a word (e.g. "fridge~") will pluralise
 *
 * '|x|y|' will be output as 'x' if singular or 'y' if plural
 *    (e.g. "kni|fe|ves|")
 *
 * '#' will be replaced with 'modstr' (which may contain the pluralising
 * formats given above).
 */
size_t obj_desc_name_format(char *buf, size_t max, size_t end,
		const char *fmt, const char *modstr, bool pluralise)
{
	/* Copy the string */
	while (*fmt) {
		/* Skip */
		if (*fmt == '&') {
			while (*fmt == ' ' || *fmt == '&')
				fmt++;
			continue;
		} else if (*fmt == '~') {
			/* Pluralizer (regular English plurals) */
			char prev = *(fmt - 1);

			if (!pluralise)	{
				fmt++;
				continue;
			}

			/* e.g. cutlass-e-s, torch-e-s, box-e-s */
			if (prev == 's' || prev == 'h' || prev == 'x')
				strnfcat(buf, max, &end, "es");
			else
				strnfcat(buf, max, &end, "s");
		} else if (*fmt == '|') {
			/* Special plurals 
			* e.g. kni|fe|ves|
			*          ^  ^  ^ */
			const char *singular = fmt + 1;
			const char *plural   = strchr(singular, '|');
			const char *endmark  = NULL;

			if (plural) {
				plural++;
				endmark = strchr(plural, '|');
			}

			if (!singular || !plural || !endmark) return end;

			if (!pluralise)
				strnfcat(buf, max, &end, "%.*s",
					(int) (plural - singular) - 1,
					singular);
			else
				strnfcat(buf, max, &end, "%.*s",
					(int) (endmark - plural), plural);

			fmt = endmark;
		} else if (*fmt == '#' && modstr) {
			/* Add modstr, with pluralisation if relevant */
			end = obj_desc_name_format(buf, max, end, modstr, NULL,	pluralise);
		}

		else
			buf[end++] = *fmt;

		fmt++;
	}

	buf[end] = 0;

	return end;
}


/**
 * Format object obj's name into 'buf'.
 */
static size_t obj_desc_name(char *buf, size_t max, size_t end,
		const struct object *obj, bool prefix, uint32_t mode,
		bool terse, const struct player *p)
{
	bool store = mode & ODESC_STORE ? true : false;
	bool spoil = mode & ODESC_SPOIL ? true : false;
	uint16_t number = (mode & ODESC_ALTNUM) ?
		(mode & 0xFFFF0000) >> 16 : obj->number;
	
	/* Actual name for flavoured objects if aware, or in store, or spoiled */
	bool aware = object_flavor_is_aware(obj) || store || spoil;
	/* Pluralize if (not forced singular) and
	 * (not a known/visible artifact) and
	 * (not one in stack or forced plural) */
	bool plural = !(mode & ODESC_SINGULAR) &&
		!obj->artifact &&
		(number != 1 || (mode & ODESC_PLURAL));
	const char *basename = obj_desc_get_basename(obj, aware, terse,
		mode, p);
	const char *modstr = obj_desc_get_modstr(obj->kind);

	/* Quantity prefix */
	if (prefix)
		end = obj_desc_name_prefix(buf, max, end, obj, basename,
			modstr, terse, number);

	/* Base name */
	/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_object_base(obj->kind, modstr, plural)), /* AB_NAMING_END */end = obj_desc_name_format(buf, max, end, basename, modstr, plural);

	/* Append extra names of various kinds */
	if (object_is_known_artifact(obj))
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_artifact_suffix(obj->artifact)), /* AB_NAMING_END */strnfcat(buf, max, &end, " %s", obj->artifact->name);
	else if ((obj->known->ego && !(mode & ODESC_NOEGO)) || (obj->ego && store))
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_ego_suffix(obj->ego)), /* AB_NAMING_END */strnfcat(buf, max, &end, " %s", obj->ego->name);
	else if (aware && !obj->artifact &&
			 (obj->kind->flavor || obj->kind->tval == TV_SCROLL)) {
		if (terse)
			/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_kind_suffix("quoted", obj->kind)), /* AB_NAMING_END */strnfcat(buf, max, &end, " '%s'", obj->kind->name);
		else
			/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_kind_suffix("of", obj->kind)), /* AB_NAMING_END */strnfcat(buf, max, &end, " of %s", obj->kind->name);
	}

	return end;
}

/**
 * Is obj armor?
 */
static bool obj_desc_show_armor(const struct object *obj,
		const struct player *p)
{
	return (!p || p->obj_k->ac) && (obj->ac || tval_is_armor(obj));
}

/**
 * Special descriptions for types of chest traps
 */
static size_t obj_desc_chest(const struct object *obj, char *buf, size_t max,
							 size_t end)
{
	if (!tval_is_chest(obj)) return end;

	/* The chest is unopened, but we know nothing about its trap/lock */
	if (obj->pval && !obj->known->pval) return end;

	/* Describe the traps */
	strnfcat(buf, max, &end, " (%s)", chest_trap_name(obj));

	return end;
}

/**
 * Describe combat properties of an item - damage dice, to-hit, to-dam, armor
 * class, missile multipler
 */
static size_t obj_desc_combat(const struct object *obj, char *buf, size_t max, 
		size_t end, uint32_t mode, const struct player *p)
{
	bool spoil = mode & ODESC_SPOIL ? true : false;
	int to_h, to_d, to_a;

	/* Display damage dice if they are known */
	if (kf_has(obj->kind->kind_flags, KF_SHOW_DICE) &&
		(!p || (p->obj_k->dd && p->obj_k->ds))) {
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_dice(obj->dd, obj->ds)), /* AB_NAMING_END */strnfcat(buf, max, &end, " (%dd%d)", obj->dd, obj->ds);
	}

	/* Display shooting power as part of the multiplier */
	if (kf_has(obj->kind->kind_flags, KF_SHOW_MULT)) {
		strnfcat(buf, max, &end, " (x%d)",
				 /* AB_NAMING_BEGIN */AB_NAMING_NUMBER("multiplier", /* AB_NAMING_END */obj->pval + obj->modifiers[OBJ_MOD_MIGHT]/* AB_NAMING_BEGIN */)/* AB_NAMING_END */);
	}

	/* No more if the object hasn't been assessed */
	if (!((obj->notice & OBJ_NOTICE_ASSESSED) || spoil)) return end;

	to_h = object_to_hit(obj);
	to_d = object_to_dam(obj);
	to_a = object_to_ac(obj);

	/* Show weapon bonuses if we know of any */
	if ((!p || (p->obj_k->to_h && p->obj_k->to_d))
			&& (tval_is_weapon(obj) || to_d
			|| (to_h && !tval_is_body_armor(obj))
			|| ((!object_has_standard_to_h(obj)
			|| obj->to_h != to_h)
			&& !obj->artifact && !obj->ego))) {
		/* In general show full combat bonuses */
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_bonus_pair(to_h, to_d)), /* AB_NAMING_END */strnfcat(buf, max, &end, " (%+d,%+d)", to_h, to_d);
	} else if (obj->to_h < 0 && object_has_standard_to_h(obj)) {
		/* Special treatment for body armor with only a to-hit penalty */
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_bonus_single("standard_hit_penalty", obj->to_h)), /* AB_NAMING_END */strnfcat(buf, max, &end, " (%+d)", obj->to_h);
	} else if (to_d != 0 && (!p || p->obj_k->to_d)) {
		/* To-dam rune known only */
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_bonus_single("damage", to_d)), /* AB_NAMING_END */strnfcat(buf, max, &end, " (%+d)", to_d);
	} else if (to_h != 0 && (!p || p->obj_k->to_h)) {
		/* To-hit rune known only */
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_bonus_single("hit", to_h)), /* AB_NAMING_END */strnfcat(buf, max, &end, " (%+d)", to_h);
	}

	/* Show armor bonuses */
	if (!p || p->obj_k->to_a) {
		if (obj_desc_show_armor(obj, p))
			/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_armor("base_bonus", obj->ac, to_a)), /* AB_NAMING_END */strnfcat(buf, max, &end, " [%d,%+d]", obj->ac, to_a);
		else if (to_a)
			/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_armor("bonus", 0, to_a)), /* AB_NAMING_END */strnfcat(buf, max, &end, " [%+d]", to_a);
	} else if (obj_desc_show_armor(obj, p)) {
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_armor("base", obj->ac, 0)), /* AB_NAMING_END */strnfcat(buf, max, &end, " [%d]", obj->ac);
	}

	return end;
}

/**
 * Describe remaining light for refuellable lights
 */
static size_t obj_desc_light(const struct object *obj, char *buf, size_t max,
							 size_t end)
{
	/* Fuelled light sources get number of remaining turns appended */
	if (tval_is_light(obj) && !of_has(obj->flags, OF_NO_FUEL))
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_number("fuel", obj->timeout)), /* AB_NAMING_END */strnfcat(buf, max, &end, " (%d turns)", obj->timeout);

	return end;
}

/**
 * Describe numerical modifiers to stats and other player qualities which
 * allow numerical bonuses - speed, stealth, etc
 */
static size_t obj_desc_mods(const struct object *obj, char *buf, size_t max,
							size_t end)
{
	int i, j, num_mods = 0;
	int mods[OBJ_MOD_MAX] = { 0 };

	/* Run through possible modifiers and store distinct ones */
	for (i = 0; i < OBJ_MOD_MAX; i++) {
		/* Check for known non-zero mods */
		if (obj->modifiers[i] != 0) {
			/* If no mods stored yet, store and move on */
			if (!num_mods) {
				mods[num_mods++] = obj->modifiers[i];
				continue;
			}

			/* Run through the existing mods, quit on duplicates */
			for (j = 0; j < num_mods; j++)
				if (mods[j] == obj->modifiers[i]) break;

			/* Add another mod if needed */
			if (j == num_mods)
				mods[num_mods++] = obj->modifiers[i];
		}
	}

	if (!num_mods) return end;

	/* Print the modifiers */
	/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_modifiers(mods, num_mods)), /* AB_NAMING_END */strnfcat(buf, max, &end, " <");
	for (j = 0; j < num_mods; j++) {
		if (j) strnfcat(buf, max, &end, ", ");
		strnfcat(buf, max, &end, "%+d", mods[j]);
	}
	strnfcat(buf, max, &end, ">");

	return end;
}

/**
 * Describe charges or charging status for re-usable items with magic effects
 */
static size_t obj_desc_charges(const struct object *obj, char *buf, size_t max,
		size_t end, uint32_t mode)
{
	bool aware = object_flavor_is_aware(obj) || (mode & ODESC_STORE);

	/* Wands and staffs have charges, others may be charging */
	if (aware && tval_can_have_charges(obj)) {
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_number("charges", obj->pval)), /* AB_NAMING_END */strnfcat(buf, max, &end, " (%d charge%s)", obj->pval,
				 PLURAL(obj->pval));
	} else if (obj->timeout > 0) {
		if (tval_is_rod(obj) && obj->number > 1)
			strnfcat(buf, max, &end, " (%d charging)", /* AB_NAMING_BEGIN */AB_NAMING_NUMBER("charging", /* AB_NAMING_END */number_charging(obj)/* AB_NAMING_BEGIN */)/* AB_NAMING_END */);
		else if (tval_is_rod(obj) || obj->activation || obj->effect)
			/* Artifacts, single rods */
			/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_charging()), /* AB_NAMING_END */strnfcat(buf, max, &end, " (charging)");
	}

	return end;
}

/**
 * Add player-defined inscriptions or game-defined descriptions
 */
static size_t obj_desc_inscrip(const struct object *obj, char *buf,
		size_t max, size_t end, const struct player *p)
{
	const char *u[6] = { 0, 0, 0, 0, 0, 0 };
	int n = 0;

	/* Get inscription */
	if (obj->note)
		u[n++] = quark_str(obj->note)/* AB_NAMING_BEGIN */, AB_NAMING_CAPTURE(ab_naming_inscription_user(u[n - 1]))/* AB_NAMING_END */;

	/* Use special inscription, if any */
	if (!object_flavor_is_aware(obj)) {
		if (tval_can_have_charges(obj) && (obj->pval == 0))
			/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_inscription_tag("object.annotation.empty")), /* AB_NAMING_END */u[n++] = "empty";
		if (object_flavor_was_tried(obj))
			/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_inscription_tag("object.annotation.tried")), /* AB_NAMING_END */u[n++] = "tried";
	}

	/* Note curses */
	if (obj->known->curses)
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_inscription_tag("object.annotation.cursed")), /* AB_NAMING_END */u[n++] = "cursed";

	/* Note ignore */
	if (p && ignore_item_ok(p, obj))
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_inscription_tag("object.annotation.ignore")), /* AB_NAMING_END */u[n++] = "ignore";

	/* Note unknown properties */
	if (!object_runes_known(obj) && (obj->known->notice & OBJ_NOTICE_ASSESSED))
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_inscription_tag("object.annotation.unknown")), /* AB_NAMING_END */u[n++] = "??";

	/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_inscriptions_finish());
	/* AB_NAMING_END */if (n) {
		int i;
		for (i = 0; i < n; i++) {
			if (i == 0)
				strnfcat(buf, max, &end, " {");
			strnfcat(buf, max, &end, "%s", u[i]);
			if (i < n - 1)
				strnfcat(buf, max, &end, ", ");
		}

		strnfcat(buf, max, &end, "}");
	}

	return end;
}


/**
 * Add "unseen" to the end of unaware items in stores,
 * and "??" to not fully known unflavored items 
 */
static size_t obj_desc_aware(const struct object *obj, char *buf, size_t max,
							 size_t end)
{
	if (!object_flavor_is_aware(obj)) {
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_store_annotation("object.store.unseen")), /* AB_NAMING_END */strnfcat(buf, max, &end, " {unseen}");
	} else if (!object_runes_known(obj)) {
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_store_annotation("object.store.unknown")), /* AB_NAMING_END */strnfcat(buf, max, &end, " {??}");
	} else if (obj->known->curses) {
		/* AB_NAMING_BEGIN */AB_NAMING_CAPTURE(ab_naming_store_annotation("object.store.cursed")), /* AB_NAMING_END */strnfcat(buf, max, &end, " {cursed}");
	}

	return end;
}


/**
 * Describes item `obj` into buffer `buf` of size `max`.
 *
 * \param buf is the buffer for the description.  Must have space for at least
 * max bytes.
 * \param max is the size of the buffer, in bytes.
 * \param obj is the object to describe.
 * \param mode must be a bitwise-or of zero or one more of the following:
 * ODESC_PREFIX prepends a 'the', 'a' or number
 * ODESC_BASE results in a base description.
 * ODESC_COMBAT will add to-hit, to-dam and AC info.
 * ODESC_EXTRA will add pval/charge/inscription/ignore info.
 * ODESC_PLURAL will pluralise regardless of the number in the stack.
 * ODESC_STORE turns off ignore markers, for in-store display.
 * ODESC_SPOIL treats the object as fully identified.
 * ODESC_CAPITAL capitalises the object name.
 * ODESC_TERSE causes a terse name to be used.
 * ODESC_NOEGO omits ego names.
 * ODESC_ALTNUM causes the high 16 bits of mode to be used as the number
 * of objects instead of using obj->number.  Note that using ODESC_ALTNUM
 * is not fully compatible with ODESC_EXTRA:  the display of number of rods
 * charging does not account for the alternate number.
 * \param p is the player whose knowledge is factored into the description.
 * If p is NULL, the description is for an omniscient observer.
 *
 * \returns The number of bytes used of the buffer.
 */
size_t object_desc(char *buf, size_t max, const struct object *obj,
		uint32_t mode, const struct player *p)
{
	/* AB_NAMING_BEGIN */
#ifdef __EMSCRIPTEN__
	struct ab_naming_session ab_naming_capture;
	ab_naming_object_begin(&ab_naming_capture, buf, max, mode, obj);
#endif
	/* AB_NAMING_END */bool prefix = mode & ODESC_PREFIX ? true : false;
	bool spoil = mode & ODESC_SPOIL ? true : false;
	bool terse = mode & ODESC_TERSE ? true : false;

	size_t end = 0;

	/* Simple description for null item */
	if (!obj || !obj->known)
		return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_literal("object.nothing")), AB_NAMING_OBJECT_FINISH(/* AB_NAMING_END */strnfmt(buf, max, "(nothing)")/* AB_NAMING_BEGIN */))/* AB_NAMING_END */;

	/* Unknown itema and cash get straightforward descriptions */
	if (obj->known && obj->kind != obj->known->kind) {
		if (prefix)
			return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_literal("object.unknown.prefixed")), AB_NAMING_OBJECT_FINISH(/* AB_NAMING_END */strnfmt(buf, max, "an unknown item")/* AB_NAMING_BEGIN */))/* AB_NAMING_END */;
		return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_literal("object.unknown.plain")), AB_NAMING_OBJECT_FINISH(/* AB_NAMING_END */strnfmt(buf, max, "unknown item")/* AB_NAMING_BEGIN */))/* AB_NAMING_END */;
	}

	if (tval_is_money(obj))
		return /* AB_NAMING_BEGIN */(AB_NAMING_CAPTURE(ab_naming_money_prepare(obj->pval, obj->kind)), AB_NAMING_OBJECT_FINISH(/* AB_NAMING_END */strnfmt(buf, max, "%d gold pieces worth of %s%s",
				obj->pval, obj->kind->name,
				/* AB_NAMING_BEGIN */AB_NAMING_MONEY_IGNORE(/* AB_NAMING_END */ignore_item_ok(p, obj)/* AB_NAMING_BEGIN */)/* AB_NAMING_END */ ? " {ignore}" : "")/* AB_NAMING_BEGIN */))/* AB_NAMING_END */;

	/* Egos and kinds whose name we know are seen */
	if (obj->known->ego && !spoil)
		obj->ego->everseen = true;

	if (object_flavor_is_aware(obj) && !spoil)
		obj->kind->everseen = true;

	/** Construct the name **/

	/* Copy the base name to the buffer */
	end = obj_desc_name(buf, max, end, obj, prefix, mode, terse, p);

	/* Combat properties */
	if (mode & ODESC_COMBAT) {
		if (tval_is_chest(obj))
			end = obj_desc_chest(obj, buf, max, end);
		else if (tval_is_light(obj))
			end = obj_desc_light(obj, buf, max, end);

		end = obj_desc_combat(obj->known, buf, max, end, mode, p);
	}

	/* Modifiers, charges, flavour details, inscriptions */
	if (mode & ODESC_EXTRA) {
		end = obj_desc_mods(obj->known, buf, max, end);

		end = obj_desc_charges(obj, buf, max, end, mode);

		if (mode & ODESC_STORE)
			end = obj_desc_aware(obj, buf, max, end);
		else
			end = obj_desc_inscrip(obj, buf, max, end, p);
	}

	return /* AB_NAMING_BEGIN */AB_NAMING_OBJECT_FINISH(/* AB_NAMING_END */end/* AB_NAMING_BEGIN */)/* AB_NAMING_END */;
}

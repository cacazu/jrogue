/* AB_GAME_STATIC_BEGIN */
#include "web-static-text.h"/* AB_UI_RESIDUAL_BEGIN */
#ifdef __EMSCRIPTEN__

#include "web-ui-residual-text.h"
#include "web-death-cause.h"
#endif
/* AB_UI_RESIDUAL_END */
/* AB_GAME_STATIC_END *//**
 * \file cmd-misc.c
 * \brief Deal with miscellaneous commands.
 *
 * Copyright (c) 2010 Andi Sidwell
 *
 * This work is free software; you can redistribute it and/or modify it
 * under the terms of either:
 *
 * a) the GNU General Public License as published by the Free Software
 *    Foundation, version 2, or
 *
 * b) the "Angband licence":
 *    This software may be copied and distributed for educational, research,
 *    and not for profit purposes provided that this copyright and statement
 *    are included in all such copies.  Other copyrights may also apply.
 */

/* AB_CHECK_BEGIN */#include "web-ui-text.h"
/* AB_CHECK_END */#include "angband.h"
#include "web-death-cause.h" /* AB_DEATH_INCLUDE */
#include "buildid.h"
#include "cave.h"
#include "cmd-core.h"
#include "cmds.h"
#include "game-input.h"
#include "init.h"
#include "mon-lore.h"
#include "mon-util.h"
#include "player-calcs.h"
#include "player-history.h"/* AB_GAME_HISTORY_BEGIN */
#include "web-game-history.h"/* AB_GAME_HISTORY_END */
#include "obj-util.h"
#include "target.h"


/**
 * Toggle wizard mode
 */
void do_cmd_wizard(void)
{
	/* Verify first time */
	if (!(player->noscore & NOSCORE_WIZARD)) {
		/* Mention effects */
		/* AB_GAME_STATIC_BEGIN */AB_STATIC_MSG("game.message.cmd_misc.wizard.you_are_about_to_enter_wizard_mode_for_the", MSG_GENERIC), /* AB_GAME_STATIC_END */msg("You are about to enter 'wizard' mode for the very first time!");
		/* AB_GAME_STATIC_BEGIN */AB_STATIC_MSG("game.message.cmd_misc.wizard.this_is_a_form_of_cheating_and_your_game", MSG_GENERIC), /* AB_GAME_STATIC_END */msg("This is a form of cheating, and your game will not be scored!");
		event_signal(EVENT_MESSAGE_FLUSH);

		/* Verify request */
		if (!get_check(/* AB_CHECK_BEGIN */AB_CHECK_SOURCE("interface.check.wizard_mode", /* AB_CHECK_END */"Are you sure you want to enter wizard mode? "/* AB_CHECK_BEGIN */)/* AB_CHECK_END */))
			return;

		/* Mark savefile */
		player->noscore |= NOSCORE_WIZARD;
	}

	/* Toggle mode */
	if (player->wizard) {
		player->wizard = false;
		/* AB_GAME_STATIC_BEGIN */AB_STATIC_MSG("game.message.cmd_misc.wizard.wizard_mode_off", MSG_GENERIC), /* AB_GAME_STATIC_END */msg("Wizard mode off.");
	} else {
		player->wizard = true;
		/* AB_GAME_STATIC_BEGIN */AB_STATIC_MSG("game.message.cmd_misc.wizard.wizard_mode_on", MSG_GENERIC), /* AB_GAME_STATIC_END */msg("Wizard mode on.");
	}

	/* Update monsters */
	player->upkeep->update |= (PU_MONSTERS);

	/* Redraw "title" */
	player->upkeep->redraw |= (PR_TITLE);
}

/**
 * Retire
 */
void do_cmd_retire(struct command *cmd)
{
	/* Treat retired character as dead to satisfy end of game logic. */
	player->is_dead = true;
	my_strcpy(player->died_from, "Retiring", sizeof(player->died_from));
#ifdef __EMSCRIPTEN__ /* AB_DEATH */
	ab_dc_set_fixed("interface.death.cause.retired");
#endif /* AB_DEATH */
}

/**
 * Record the player's thoughts as a note.
 *
 * This both displays the note back to the player and adds it to the game log.
 * Two fancy note types are supported: notes beginning with "/say" will be
 * written as 'Frodo says: "____"', and notes beginning with "/me" will
 * be written as 'Frodo ____'.
 */
void do_cmd_note(void)
{
	/* Allocate/Initialize strings to get and format user input. */
	char tmp[70];
	char note[90];
	my_strcpy(tmp, "", sizeof(tmp));
	my_strcpy(note, "", sizeof(note));

	/* Read a line of input from the user */
	if (!get_string("Note: ", tmp, sizeof(tmp))) return;

	/* Ignore empty notes */
	if (!tmp[0] || (tmp[0] == ' ')) return;

	/* Format the note correctly, supporting some cute /me commands */
	if (strncmp(tmp, "/say ", 5) == 0)
		/* AB_GAME_HISTORY_BEGIN */AB_GAME_HISTORY_BEFORE(ab_game_history_prepare_note(1,player->full_name,&tmp[5],note),/* AB_GAME_HISTORY_END *//* AB_UI_RESIDUAL_BEGIN */AB_UR_NOTE(1,player->full_name,&tmp[5],/* AB_UI_RESIDUAL_END */strnfmt(note, sizeof(note), "-- %s says: \"%s\"", player->full_name,
				&tmp[5])/* AB_UI_RESIDUAL_BEGIN */)/* AB_UI_RESIDUAL_END *//* AB_GAME_HISTORY_BEGIN */)/* AB_GAME_HISTORY_END */;
	else if (strncmp(tmp, "/me", 3) == 0)
		/* AB_GAME_HISTORY_BEGIN */AB_GAME_HISTORY_BEFORE(ab_game_history_prepare_note(2,player->full_name,&tmp[3],note),/* AB_GAME_HISTORY_END *//* AB_UI_RESIDUAL_BEGIN */AB_UR_NOTE(2,player->full_name,&tmp[3],/* AB_UI_RESIDUAL_END */strnfmt(note, sizeof(note), "-- %s%s", player->full_name, &tmp[3])/* AB_UI_RESIDUAL_BEGIN */)/* AB_UI_RESIDUAL_END *//* AB_GAME_HISTORY_BEGIN */)/* AB_GAME_HISTORY_END */;
	else
		/* AB_GAME_HISTORY_BEGIN */AB_GAME_HISTORY_BEFORE(ab_game_history_prepare_note(3,NULL,tmp,note),/* AB_GAME_HISTORY_END *//* AB_UI_RESIDUAL_BEGIN */AB_UR_NOTE(3,NULL,tmp,/* AB_UI_RESIDUAL_END */strnfmt(note, sizeof(note), "-- Note: %s", tmp)/* AB_UI_RESIDUAL_BEGIN */)/* AB_UI_RESIDUAL_END *//* AB_GAME_HISTORY_BEGIN */)/* AB_GAME_HISTORY_END */;

	/* Display the note (omitting the "-- " prefix) */
	/* AB_UI_RESIDUAL_BEGIN */AB_UR_BEFORE((ab_ur_note_message()),/* AB_UI_RESIDUAL_END */msg("%s", &note[3])/* AB_UI_RESIDUAL_BEGIN */)/* AB_UI_RESIDUAL_END */;

	/* Add a history entry */
	history_add(player, note, HIST_USER_INPUT);
}

#ifdef ALLOW_BORG

extern void do_cmd_borg(void);

/*
 * Verify use of "borg" mode
 */
void do_cmd_try_borg(void)
{
	/* Ask first time */
	if (!(player->noscore & NOSCORE_BORG))
	{
		/* Mention effects */
		/* AB_GAME_STATIC_BEGIN */AB_STATIC_MSG("game.message.cmd_misc.try_borg.you_are_about_to_use_the_dangerous_unsupported_borg", MSG_GENERIC), /* AB_GAME_STATIC_END */msg("You are about to use the dangerous, unsupported, borg commands!");
		/* AB_GAME_STATIC_BEGIN */AB_STATIC_MSG("game.message.cmd_misc.try_borg.your_machine_may_crash_and_your_savefile_may_become", MSG_GENERIC), /* AB_GAME_STATIC_END */msg("Your machine may crash, and your savefile may become corrupted!");
		event_signal(EVENT_MESSAGE_FLUSH);

		/* Verify request */
		if (!get_check(/* AB_CHECK_BEGIN */AB_CHECK_SOURCE("interface.check.borg_commands", /* AB_CHECK_END */"Are you sure you want to use the borg commands? "/* AB_CHECK_BEGIN */)/* AB_CHECK_END */))
			return;

		/* Mark savefile */
		player->noscore |= NOSCORE_BORG;
	}

	/* Okay */
	do_cmd_borg();
}

#endif /* ALLOW_BORG */
